<?php 

$lang["alpha_dash"] = "";
$lang["alpha_numeric"] = "";
$lang["exact_length"] = "";
$lang["greater_than"] = "";
$lang["is_natural"] = "";
$lang["is_natural_no_zero"] = "";
$lang["is_numeric"] = "";
$lang["is_unique"] = "";
$lang["less_than"] = "";
$lang["max_length"] = "";
$lang["min_length"] = "";
$lang["regex_match"] = "";
$lang["valid_email"] = "";
$lang["valid_emails"] = "";
$lang["valid_ip"] = "";
$lang["valid_url"] = "";
