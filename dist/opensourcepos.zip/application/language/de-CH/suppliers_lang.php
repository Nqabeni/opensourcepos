<?php 

$lang["suppliers_account_number"] = "Konto-Nr.";
$lang["suppliers_agency_name"] = "Name der Agentur";
$lang["suppliers_cannot_be_deleted"] = "Kann gewählte Lieferanten nicht löschen, einer oder mehrere weisen Verkäufe aus.";
$lang["suppliers_company_name"] = "Firmenname";
$lang["suppliers_company_name_required"] = "Firmenname ist erforderlich";
$lang["suppliers_confirm_delete"] = "Wollen Sie die gewählten Lieferanten löschen?";
$lang["suppliers_error_adding_updating"] = "Fehler beim Hinzufügen/Ändern";
$lang["suppliers_new"] = "Neuer Lieferant";
$lang["suppliers_none_selected"] = "Sie haben keinen Lieferanten zum Löschen ausgewählt";
$lang["suppliers_one_or_multiple"] = "Lieferanten";
$lang["suppliers_successful_adding"] = "Erfolgreich hinzugefügt";
$lang["suppliers_successful_deleted"] = "Löschung erfolgreich";
$lang["suppliers_successful_updating"] = "Änderung erfolgreich";
$lang["suppliers_supplier"] = "Lieferant";
$lang["suppliers_supplier_id"] = "ID";
$lang["suppliers_update"] = "Ändere Lieferant";
