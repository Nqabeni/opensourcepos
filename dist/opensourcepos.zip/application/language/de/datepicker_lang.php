<?php 

$lang["datepicker_all_time"] = "Von Beginn weg";
$lang["datepicker_apply"] = "Ausführen";
$lang["datepicker_cancel"] = "Abbrechen";
$lang["datepicker_custom"] = "Benutzerdefiniert";
$lang["datepicker_from"] = "Von";
$lang["datepicker_last_30"] = "Letzte 30 Tage";
$lang["datepicker_last_7"] = "Letzte 7 Tage";
$lang["datepicker_last_financial_year"] = "";
$lang["datepicker_last_month"] = "Letzter Monat";
$lang["datepicker_last_year"] = "Letztes Jahr";
$lang["datepicker_same_month_last_year"] = "Dieser Monat letzten Jahres";
$lang["datepicker_same_month_to_same_day_last_year"] = "Dieser Monat bis Heute letzten Jahres";
$lang["datepicker_this_financial_year"] = "";
$lang["datepicker_this_month"] = "Dieser Monat";
$lang["datepicker_this_year"] = "Dieses Jahr";
$lang["datepicker_to"] = "Bis";
$lang["datepicker_today"] = "Heute";
$lang["datepicker_today_last_year"] = "Heute letzten Jahres";
$lang["datepicker_weekstart"] = "1";
$lang["datepicker_yesterday"] = "Gestern";
