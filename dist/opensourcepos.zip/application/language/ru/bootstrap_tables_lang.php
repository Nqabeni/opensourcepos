<?php 

$lang["tables_all"] = "All";
$lang["tables_columns"] = "Колонки";
$lang["tables_hide_show_pagination"] = "Hide/Show pagination";
$lang["tables_loading"] = "Пожалуйста, подождите, идёт загрузка...";
$lang["tables_page_from_to"] = "Записи с {0} по {1} из {2}";
$lang["tables_refresh"] = "Обновить";
$lang["tables_rows_per_page"] = "{0} записей на страницу";
$lang["tables_toggle"] = "Переключить";
