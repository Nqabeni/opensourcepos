<?php 

$lang["login_go"] = "登入";
$lang["login_invalid_username_and_password"] = "錯誤的帳號或密碼";
$lang["login_login"] = "登入";
$lang["login_password"] = "密碼";
$lang["login_username"] = "帳號";
